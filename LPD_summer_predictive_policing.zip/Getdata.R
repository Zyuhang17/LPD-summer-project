## Load data
LPD_location <- read_csv("LPD_location.csv")

# clean data
mydata <- data.frame(LPD_location[1:6])
cleaned_data <- na.omit(mydata)
cleaned_data$Priority <- as.numeric(cleaned_data$Priority)
cleaned_data[is.na(cleaned_data)] <- 10
Crime <- cleaned_data[c(4,2,3,5,6)]