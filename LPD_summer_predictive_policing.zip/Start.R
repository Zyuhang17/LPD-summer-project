# Load required libraries
library(CAST)
library(virtualspecies)
library(caret)
library(raster)
library(sp)
library(sf)
library(viridis)
library(latticeExtra)
library(gridExtra)
library(RODBC)
library(xgboost)
library(ROCR)

# Set seed
set.seed(1001)

#load Crime data
Crime$Target[Crime$Priority<=8] <- 0
Crime$Target[Crime$Priority>8] <- 1

# plot
# plot <- ggplot()

# Read in data
# dbhandle <- odbcDriverConnect('driver={mypurdueserver};server=https://web.ics.purdue.edu/software/phpMyAdmin/;database=crime;trusted_connection=true')
# split into train and test
dt = sort(sample(nrow(Crime), nrow(Crime)*.7))
train<-Crime[dt,]
train <- train[,2:ncol(train)]
test<-Crime[-dt,]
test <- test[,2:ncol(test)]

head(train)

# Get feature names (all but first column which is the target)
feature.names <- names(train)[1:ncol(train)-1]

print(feature.names)

# Make train and test matrices
dtrain <- xgb.DMatrix(data.matrix(train[,feature.names]), label=train$Target)
dtest <- xgb.DMatrix(data.matrix(test[,feature.names]), label=test$Target)

# Training parameters
watchlist <- list(eval = dtest, train = dtrain)

param <- list(  objective           = "binary:logistic", 
                booster             = "gbtree",
                eta                 = 0.01,
                max_depth           = 10,
                eval_metric         = "auc"
)

# Run model
clf <- xgb.train(   params                  = param, 
                    data                    = dtrain, 
                    nrounds                 = 100, 
                    verbose                 = 2, 
                    early_stopping_rounds   = 10,
                    watchlist               = watchlist,
                    maximize               = TRUE)

# Compute feature importance matrix
importance_matrix <- xgb.importance(feature.names, model = clf)

# Graph important features
xgb.plot.importance(importance_matrix[1:10,])

# Predict on test data
preds <- predict(clf, dtest)

# Graph AUC curve
xgb.pred <- prediction(preds, test$Target)
xgb.perf <- performance(xgb.pred, "tpr", "fpr")

plot(xgb.perf,
     avg="threshold",
     colorize=TRUE,
     lwd=1,
     main="ROC Curve w/ Thresholds",
     print.cutoffs.at=seq(0, 1, by=0.05),
     text.adj=c(-0.5, 0.5),
     text.cex=0.5)
grid(col="lightgray")
axis(1, at=seq(0, 1, by=0.1))
axis(2, at=seq(0, 1, by=0.1))
abline(v=c(0.1, 0.3, 0.5, 0.7, 0.9), col="lightgray", lty="dotted")
abline(h=c(0.1, 0.3, 0.5, 0.7, 0.9), col="lightgray", lty="dotted")
lines(x=c(0, 1), y=c(0, 1), col="black", lty="dotted")

# Set our cutoff threshold
preds.resp <- ifelse(preds >= 0.5, 1, 0)

# Create the confusion matrix
confusionMatrix(as.factor(preds.resp), as.factor(test$Target), positive = "1")

# Merge the predictions with the test data
results <- cbind(test, preds)
head(results)